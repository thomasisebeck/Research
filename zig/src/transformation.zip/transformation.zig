const std = @import("std");
const print = std.debug.print;
const assert = std.debug.assert;
const utils = @import("utls.zig");

const Point = struct { x: f64, y: f64 };

fn getDistanceHighFidelity(from: *const Point, to: *const Point) f64 {
    // return the euclidean distance
    const x_diff = to.x - from.x;
    const y_diff = to.y - from.y;

    // expensive square root calculation
    return std.math.sqrt((x_diff * x_diff) + (y_diff * y_diff));
}

fn getDistanceMediumFidelity(from: *const Point, to: *const Point) f64 {
    // alpha max plus beta min distance
    const x_diff = @abs(to.x - from.x);
    const y_diff = @abs(to.y - from.y);
    const max_diff = if (x_diff > y_diff) x_diff else y_diff;
    const min_diff = if (x_diff > y_diff) y_diff else x_diff;

    return max_diff + (0.5 * min_diff);
}

fn getDistanceLowFidelity(from: *const Point, to: *const Point) f64 {
    // chebyshev distance
    const x_diff = @abs(to.x - from.x);
    const y_diff = @abs(to.y - from.y);

    return if (x_diff > y_diff) x_diff else y_diff;
}

const Type = enum { HIGH, MED, LOW };

pub fn distCom(comptime policy: Type, from: *const Point, to: *const Point) f64 {
    switch (policy) {
        .HIGH => return getDistanceHighFidelity(from, to),
        .MED => return getDistanceMediumFidelity(from, to),
        .LOW => return getDistanceLowFidelity(from, to),
    }
}

pub fn distRun(policy: Type, from: *const Point, to: *const Point) f64 {
    switch (policy) {
        .HIGH => return getDistanceHighFidelity(from, to),
        .MED => return getDistanceMediumFidelity(from, to),
        .LOW => return getDistanceLowFidelity(from, to),
    }
}

const INPUT_SIZE = 100;

pub fn main(init: std.process.Init) !void {
    const io = init.io;

    const input = try utils.readFromFile(1000, i32, io, "input_transformation.txt");

    //   print("This is the array of 1000 numbers... \n", .{});
    // _ = try utils.printArray(&input);

    var start_time = std.Io.Clock.now(.awake, io);

    var sum: f64 = 0;

    var pseudo_rand_state: u32 = 12345;

    for (0..1000) |_| {
        for (0..input.len - 3) |index| {
            const from = Point{ .x = input[index], .y = input[index + 1] };

            const to = Point{ .x = input[index + 2], .y = input[index + 3] };

            pseudo_rand_state = (pseudo_rand_state *% 1103515245) +% 12345;
            const rand_val = (pseudo_rand_state / 65536) % 3;

            const runtime_policy: Type = case: {
                if (rand_val == 0) break :case .LOW;
                if (rand_val == 1) break :case .MED;
                break :case .HIGH;
            };

            // switch (runtime_policy) {
            //     .LOW => sum += distRun(.LOW, &from, &to),
            //     .MED => sum += distRun(.MED, &from, &to),
            //     .HIGH => sum += distRun(.HIGH, &from, &to),
            // }

            switch (runtime_policy) {
                .LOW => sum += distCom(.LOW, &from, &to),
                .MED => sum += distCom(.MED, &from, &to),
                .HIGH => sum += distCom(.HIGH, &from, &to),
            }
        }
    }

    const end_time = std.Io.Clock.now(.awake, io);

    const duration = start_time.durationTo(end_time);

    std.debug.print("Processed loop in: {} ns\n", .{duration.toNanoseconds()});
    std.debug.print("sum: {}\n", .{sum});
}
